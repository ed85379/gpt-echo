
let ws = null;

function connectWebSocket() {
    ws = new WebSocket("ws://localhost:5000/ws");

    ws.onopen = () => {
        console.log("WebSocket connected");
        ws.send("Extension connected.");
    };

    ws.onmessage = (event) => {
        chrome.runtime.sendMessage({ type: "server_message", text: event.data });
    };

    ws.onclose = () => {
        console.log("WebSocket disconnected, retrying...");
        setTimeout(connectWebSocket, 3000);
    };

    ws.onerror = (error) => {
        console.error("WebSocket error", error);
        ws.close();
    };
}

connectWebSocket();

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "send_to_server" && ws && ws.readyState === WebSocket.OPEN) {
        ws.send(message.text);
    }
});
