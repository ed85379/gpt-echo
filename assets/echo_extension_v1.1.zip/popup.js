
document.getElementById("send").addEventListener("click", () => {
    const input = document.getElementById("message");
    const msg = input.value.trim();
    if (!msg) return;
    addMessage("Me", msg);
    chrome.runtime.sendMessage({ type: "send_to_server", text: msg });
    input.value = "";
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "server_message") {
        addMessage("Echo", message.text);
    }
});

function addMessage(sender, text) {
    const chat = document.getElementById("chat");
    const div = document.createElement("div");
    div.className = "entry " + (sender === "Me" ? "me" : "echo");
    div.textContent = sender + ": " + text;
    chat.appendChild(div);
    chat.scrollTop = chat.scrollHeight;
}
